02 학생용 수업 자료

1. 이 ZIP 파일의 압축을 풉니다.
2. 문서 폴더에 JDH_VibeCoding_자기이름 폴더를 만듭니다.
3. 압축을 풀어 생긴 02 폴더를 그 안에 넣습니다.
4. VS Code에서 JDH_VibeCoding_자기이름 폴더를 엽니다.

2-2에서 여는 Python 파일
- code/01_first_result.py
- code/02_four_calculations.py
- code/03_number_text_cases.py
- code/04_variables.py
- code/05_numbers_and_variables.py

03_number_text_cases.py는 숫자 덧셈, 문자열 연결, 글자와 숫자의 오류를 순서대로 보여 줍니다.
코드를 직접 수정하지 않고 교과서의 순서대로 파일을 열어 실행합니다.
