print(8 + 2)
print(8 - 2)
print(8 * 2)
print(8 / 2)
